# Sistemas Operativos

![[Introduccion a los sistemas operativos]]

![[Administracion de Procesos]]
